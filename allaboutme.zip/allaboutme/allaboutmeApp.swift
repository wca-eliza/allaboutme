//
//  allaboutmeApp.swift
//  allaboutme
//
//  Created by Eliza Wang on 2023-06-23.
//

import SwiftUI

@main
struct allaboutmeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
